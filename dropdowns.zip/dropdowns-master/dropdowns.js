
$(document).ready(function($) {
	$('.wrapper > form').hide();
	$('.wrapper form:first').show();

	$('fieldset .button').on('click', function(event) {
		event.preventDefault();
		console.log('clicked');
	 var id = $(this).attr('href');
	 console.log(id);
	 $('.wrapper form').hide();
	 $(id).fadeIn();
	});
});


jQuery(document).ready(function($) {

$('.tab__content').hide();
$('.tab__content:first').show();
$('.tab__menu ul li a:first').addClass('active');
$('.tab__menu ul li a').on('click', function(event) {
	event.preventDefault();
	$('.tab__menu ul li a').removeClass('active');
	$(this).addClass('active');
	$('.tab__content').hide();
	var href = $(this).attr('href');
	//jQuery.easing.def = "easeInOutExpo";
	$(href).fadeIn({
	 duration: 1000, 
	easing: 'easeOutQuint'});
	
});


});

(function($){
	$.fn.dropdowns = function (options) {
		
		var defaults = {
			toggleWidth: 768
		}
		
		var options = $.extend(defaults, options);
		
		var ww = document.body.clientWidth;
		
		var addParents = function() {
			$(".nav li a").each(function() {
				if ($(this).next().length > 0) {
					$(this).addClass("parent");
				}
			});
		}
		
		var adjustMenu = function() {
			if (ww < options.toggleWidth) {
				$(".toggleMenu").css("display", "inline-block");
				if (!$(".toggleMenu").hasClass("active")) {
					$(".nav").hide();
				} else {
					$(".nav").show();
				}
				$(".nav li").unbind('mouseenter mouseleave');
				$(".nav li a.parent").unbind('click').bind('click', function(e) {
					// must be attached to anchor element to prevent bubbling
					e.preventDefault();
					$(this).parent("li").toggleClass("hover");
				});
			} 
			else if (ww >= options.toggleWidth) {
				$(".toggleMenu").css("display", "none");
				$(".nav").show();
				$(".nav li").removeClass("hover");
				$(".nav li a").unbind('click');
				$(".nav li").unbind('mouseenter mouseleave').bind('mouseenter mouseleave', function() {
					// must be attached to li so that mouseleave is not triggered when hover over submenu
					$(this).toggleClass('hover');
				});
			}
		}
		
		return this.each(function() {
			$(".toggleMenu").click(function(e) {
				e.preventDefault();
				$(this).toggleClass("active");
				$(this).next(".nav").toggle();
				adjustMenu();
			});
			adjustMenu();
			addParents();
			$(window).bind('resize orientationchange', function() {
				ww = document.body.clientWidth;
				adjustMenu();
			});
		});
	
	}
})(jQuery)